from django.apps import AppConfig


class SentimentappConfig(AppConfig):
    name = 'SentimentApp'
